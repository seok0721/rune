#!/bin/bash
docker run -i -t --name=$1 --cpu-shares=100 --cpuset-cpus=0-7 --cap-add=NET_ADMIN --cap-add=SYS_RESOURCE ubuntu:xenial /bin/bash
