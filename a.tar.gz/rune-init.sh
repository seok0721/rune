#!/bin/bash
echo 127.0.0.1 controller >> /etc/hosts
echo 127.0.0.1 compute1 >> /etc/hosts
echo 127.0.0.1 block1 >> /etc/hosts
echo 127.0.0.1 object1 >> /etc/hosts
echo 127.0.0.1 compute1 >> /etc/hosts

if [[ ! -z /root/admin-openrc ]]; then
  echo "export ADMIN_PASS=`openssl rand -hex 10`
export CEILOMETER_DBPASS=`openssl rand -hex 10`
export CEILOMETER_PASS=`openssl rand -hex 10`
export CINDER_DBPASS=`openssl rand -hex 10`
export CINDER_PASS=`openssl rand -hex 10`
export DASH_DBPASS=`openssl rand -hex 10`
export DEMO_PASS=`openssl rand -hex 10`
export GLANCE_DBPASS=`openssl rand -hex 10`
export GLANCE_PASS=`openssl rand -hex 10`
export HEAT_DBPASS=`openssl rand -hex 10`
export HEAT_DOMAIN_PASS=`openssl rand -hex 10`
export HEAT_PASS=`openssl rand -hex 10`
export KEYSTONE_DBPASS=`openssl rand -hex 10`
export NEUTRON_DBPASS=`openssl rand -hex 10`
export NEUTRON_PASS=`openssl rand -hex 10`
export NOVA_DBPASS=`openssl rand -hex 10`
export NOVA_PASS=`openssl rand -hex 10`
export RABBIT_PASS=`openssl rand -hex 10`
export SWIFT_PASS=`openssl rand -hex 10`" > /root/admin-openrc
  . /root/admin-openrc
  echo "
export OS_TOKEN=$ADMIN_PASS
export OS_URL=http://controller:35357/v3
export OS_IDENTITY_API_VERSION=3

export OS_PROJECT_DOMAIN_NAME=default
export OS_USER_DOMAIN_NAME=default
export OS_PROJECT_NAME=admin
export OS_USERNAME=admin
export OS_PASSWORD=$ADMIN_PASS
export OS_AUTH_URL=http://controller:35357/v3
export OS_IDENTITY_API_VERSION=3
export OS_IMAGE_API_VERSION=2" >> /root/admin-openrc
fi

. /root/admin-openrc

if [[ ! -z /root/demo-openrc ]]; then
  echo "export OS_PROJECT_DOMAIN_NAME=default
export OS_USER_DOMAIN_NAME=default
export OS_PROJECT_NAME=demo
export OS_USERNAME=demo
export OS_PASSWORD=$ADMIN_PASS
export OS_AUTH_URL=http://controller:5000/v3
export OS_IDENTITY_API_VERSION=3
export OS_IMAGE_API_VERSION=2" > /root/demo-openrc
fi

A=`cat /etc/glance/glance-registry.conf.sample`; eval echo "\"$A\"" > /etc/glance/glance-registry.conf
A=`cat /etc/glance/glance-api.conf.sample`; eval echo "\"$A\"" > /etc/glance/glance-api.conf
A=`cat /etc/keystone/keystone.conf.sample`; eval echo "\"$A\"" > /etc/keystone/keystone.conf
A=`cat /etc/neutron/neutron.conf.sample`; eval echo "\"$A\"" > /etc/neutron/neutron.conf
A=`cat /etc/nova/nova.conf.sample`; eval echo "\"$A\"" > /etc/nova/nova.conf

glance-manage db_sync
keystone-manage db_sync
keystone-manage fernet_setup --keystone-user keystone --keystone-group keystone
neutron-db-manage --config-file /etc/neutron/neutron.conf --config-file /etc/neutron/plugins/ml2/ml2_conf.ini upgrade head 
nova-manage api_db sync
nova-manage db sync

service chrony start
service mysql start
service mongodb start
service rabbitmq-server start
service memcached start
service apache2 start
service docker start

rabbitmqctl add_user openstack $RABBIT_PASS
rabbitmqctl set_permissions openstack ".*" ".*" ".*"

service keystone start

service glance-api start
service glance-registry start

service nova-api start
service nova-consoleauth start
service nova-scheduler start
service nova-conductor start
service nova-novncproxy start
service nova-compute start
service libvirt-bin start

service neutron-server start
service neutron-linuxbridge-agent start
service neutron-dhcp-agent start
service neutron-metadata-agent start

# cat /proc/net/dev | tail -n 1 | sed -e 's/^ \+\([a-z0-9]\+\):.*/\1/' ethernet장치검색
# 현재 뉴트론은 프로바이더용으로 셋팅하였음. 셀프서비스용 옵션 페이지는 넘어갔음.
# 셀프서비스로 설정해야함.

# python-glanceclient 버전 2.1에서 버그 픽스되었음.
