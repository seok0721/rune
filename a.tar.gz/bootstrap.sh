#!/bin/bash
apt-get update
apt-get -y install \
  apache2  \
  chrony \
  docker.io \
  git \
  glance \
  iptables \
  keystone \
  libapache2-mod-wsgi \
  mariadb-server \
  memcached \
  mongodb-clients python-pymongo \
  mongodb-server \
  neutron-dhcp-agent \
  neutron-linuxbridge-agent \
  neutron-metadata-agent \
  neutron-plugin-ml2 \
  neutron-server \
  nova-api \
  nova-compute \
  nova-conductor \
  nova-consoleauth \
  nova-novncproxy \
  nova-scheduler \
  python-memcache \
  python-openstackclient \
  python-pip \
  python-pymysql \
  python3-dev \
  rabbitmq-server \
  vim \
  wget
pip install -U pip
pip install pymysql

# Install nova-docker
git clone http://github.com/openstack/nova-docker /usr/src/github/openstack/nova-docker
cd /usr/src/github/openstack/nova-docker
git checkout -b stable/mitaka origin/stable/mitaka
pip install /usr/src/github/openstack/nova-docker

# Start to use compute node service
service libvirt-bin start
service docker start

# Create credentials
echo "export ADMIN_PASS=`openssl rand -hex 10`
export CEILOMETER_DBPASS=`openssl rand -hex 10`
export CEILOMETER_PASS=`openssl rand -hex 10`
export CINDER_DBPASS=`openssl rand -hex 10`
export CINDER_PASS=`openssl rand -hex 10`
export DASH_DBPASS=`openssl rand -hex 10`
export DEMO_PASS=`openssl rand -hex 10`
export GLANCE_DBPASS=`openssl rand -hex 10`
export GLANCE_PASS=`openssl rand -hex 10`
export HEAT_DBPASS=`openssl rand -hex 10`
export HEAT_DOMAIN_PASS=`openssl rand -hex 10`
export HEAT_PASS=`openssl rand -hex 10`
export KEYSTONE_DBPASS=`openssl rand -hex 10`
export NEUTRON_DBPASS=`openssl rand -hex 10`
export NEUTRON_PASS=`openssl rand -hex 10`
export NOVA_DBPASS=`openssl rand -hex 10`
export NOVA_PASS=`openssl rand -hex 10`
export RABBIT_PASS=`openssl rand -hex 10`
export SWIFT_PASS=`openssl rand -hex 10`" > /root/admin-openrc

. /root/admin-openrc

echo "
export OS_TOKEN=$ADMIN_PASS
export OS_URL=http://controller:35357/v3
export OS_IDENTITY_API_VERSION=3

export OS_PROJECT_DOMAIN_NAME=default
export OS_USER_DOMAIN_NAME=default
export OS_PROJECT_NAME=admin
export OS_USERNAME=admin
export OS_PASSWORD=$ADMIN_PASS
export OS_AUTH_URL=http://controller:35357/v3
export OS_IDENTITY_API_VERSION=3
export OS_IMAGE_API_VERSION=2" >> /root/admin-openrc

. /root/admin-openrc

# Initialize hosts
echo 127.0.0.1 controller >> /etc/hosts
echo 127.0.0.1 compute1 >> /etc/hosts
echo 127.0.0.1 block1 >> /etc/hosts
echo 127.0.0.1 object1 >> /etc/hosts
echo 127.0.0.1 compute2 >> /etc/hosts

# Initialize time server
echo "server kr.pool.ntp.org iburst" >> /etc/chrony/chrony.conf
service chrony start

# Initialize SQL database
wget http://172.17.0.1:8000/etc/mysql/mariadb.conf.d/50-client.cnf -O /etc/mysql/mariadb.conf.d/50-client.cnf
wget http://172.17.0.1:8000/etc/mysql/mariadb.conf.d/50-mysql-clients.cnf -O /etc/mysql/mariadb.conf.d/50-mysql-clients.cnf
wget http://172.17.0.1:8000/etc/mysql/mariadb.conf.d/50-server.cnf -O /etc/mysql/mariadb.conf.d/50-server.cnf
service mysql start

# Initialize NoSQL database
wget http://172.17.0.1:8000/etc/mongodb.conf -O /etc/mongodb.conf
service mongodb start

# Initialize message queue
service rabbitmq-server start
rabbitmqctl add_user openstack $RABBIT_PASS
rabbitmqctl set_permissions openstack ".*" ".*" ".*"

# Initialize cache server
wget http://172.17.0.1:8000/etc/memcached.conf -O /etc/memcached.conf
service memcached start

# Initialize keystone
echo "CREATE DATABASE keystone" | mysql
echo "GRANT ALL PRIVILEGES ON keystone.* TO 'keystone'@'localhost' IDENTIFIED BY '$KEYSTONE_DBPASS'" | mysql
echo "GRANT ALL PRIVILEGES ON keystone.* TO 'keystone'@'%' IDENTIFIED BY '$KEYSTONE_DBPASS'" | mysql
echo "manual" > /etc/init/keystone.override
echo "ServerName controller" >> /etc/apache2/apache2.conf
wget http://172.17.0.1:8000/etc/apache2/sites-available/wsgi-keystone.conf -O /etc/apache2/sites-available/wsgi-keystone.conf
a2ensite wsgi-keystone
wget http://172.17.0.1:8000/etc/keystone/keystone.conf.sample -O /etc/keystone/keystone.conf.sample
A=`cat /etc/keystone/keystone.conf.sample`; eval echo "\"$A\"" > /etc/keystone/keystone.conf
keystone-manage db_sync
keystone-manage fernet_setup --keystone-user keystone --keystone-group keystone
service apache2 start

openstack service create --name keystone --description "OpenStack Identity" identity
openstack endpoint create --region RegionOne identity public http://controller:5000/v3
openstack endpoint create --region RegionOne identity internal http://controller:5000/v3
openstack endpoint create --region RegionOne identity admin http://controller:35357/v3

openstack domain create --description "Default Domain" default
openstack project create --domain default --description "Admin Project" admin
openstack user create --domain default --password $ADMIN_PASS admin
openstack role create admin
openstack role add --project admin --user admin admin

openstack project create --domain default --description "Service Project" service
openstack project create --domain default --description "Demo Project" demo
openstack user create --domain default --password $ADMIN_PASS demo
openstack role create user
openstack role add --project demo --user demo user

wget http://172.17.0.1:8000/etc/keystone/keystone-paste.ini -O /etc/keystone/keystone-paste.ini
unset OS_URL OS_TOKEN
openstack token issue
openstack service list

# Initialize glance
echo "CREATE DATABASE glance" | mysql
echo "GRANT ALL PRIVILEGES ON glance.* TO 'glance'@'localhost' IDENTIFIED BY '$GLANCE_DBPASS'" | mysql
echo "GRANT ALL PRIVILEGES ON glance.* TO 'glance'@'%' IDENTIFIED BY '$GLANCE_DBPASS'" | mysql
wget http://172.17.0.1:8000/etc/glance/glance-api.conf.sample -O /etc/glance/glance-api.conf.sample
A=`cat /etc/glance/glance-api.conf.sample`; eval echo "\"$A\"" > /etc/glance/glance-api.conf
wget http://172.17.0.1:8000/etc/glance/glance-registry.conf.sample -O /etc/glance/glance-registry.conf.sample
A=`cat /etc/glance/glance-registry.conf.sample`; eval echo "\"$A\"" > /etc/glance/glance-registry.conf
glance-manage db_sync
service glance-registry start
service glance-api start

openstack user create --domain default --password $GLANCE_PASS glance
openstack role add --project service --user glance admin
openstack service create --name glance --description "OpenStack Image" image
openstack endpoint create --region RegionOne image public http://controller:9292
openstack endpoint create --region RegionOne image internal http://controller:9292
openstack endpoint create --region RegionOne image admin http://controller:9292

wget http://download.cirros-cloud.net/0.3.4/cirros-0.3.4-x86_64-disk.img -O /root/cirros-0.3.4-x86_64-disk.img
openstack image create "cirros" --file /root/cirros-0.3.4-x86_64-disk.img --disk-format qcow2 --container-format bare --public

openstack image list

# Initialize nova
wget http://172.17.0.1:8000/etc/nova/nova.conf.sample -O /etc/nova/nova.conf.sample
A=`cat /etc/nova/nova.conf.sample`; eval echo "\"$A\"" > /etc/nova/nova.conf
wget http://172.17.0.1:8000/etc/nova/nova-compute.conf -O /etc/nova/nova-compute.conf
echo "CREATE DATABASE nova_api" | mysql
echo "CREATE DATABASE nova" | mysql
echo "GRANT ALL PRIVILEGES ON nova_api.* TO 'nova'@'localhost' IDENTIFIED BY '$NOVA_DBPASS'" | mysql
echo "GRANT ALL PRIVILEGES ON nova_api.* TO 'nova'@'%' IDENTIFIED BY '$NOVA_DBPASS'" | mysql
echo "GRANT ALL PRIVILEGES ON nova.* TO 'nova'@'localhost' IDENTIFIED BY '$NOVA_DBPASS'" | mysql
echo "GRANT ALL PRIVILEGES ON nova.* TO 'nova'@'%' IDENTIFIED BY '$NOVA_DBPASS'" | mysql
nova-manage api_db sync
nova-manage db sync

openstack user create --domain default --password $NOVA_PASS nova
openstack role add --project service --user nova admin
openstack service create --name nova --description "OpenStack Compute" compute
openstack endpoint create --region RegionOne compute public http://controller:8774/v2.1/%\(tenant_id\)s
openstack endpoint create --region RegionOne compute internal http://controller:8774/v2.1/%\(tenant_id\)s
openstack endpoint create --region RegionOne compute admin http://controller:8774/v2.1/%\(tenant_id\)s

service nova-api start
service nova-compute start
service nova-conductor start
service nova-consoleauth start
service nova-novncproxy start
service nova-scheduler start

openstack compute service list

# Initialize nova-docker

docker pull busybox
docker save busybox
openstack image create busybox --public --container-format docker --disk-format raw

# Initialize neutron
wget http://172.17.0.1:8000/etc/neutron/neutron.conf.sample -O /etc/neutron/neutron.conf.sample
A=`cat /etc/neutron/neutron.conf.sample`; eval echo "\"$A\"" > /etc/neutron/neutron.conf
wget http://172.17.0.1:8000/etc/neutron/dhcp_agent.ini -O /etc/neutron/dhcp_agent.ini
wget http://172.17.0.1:8000/etc/neutron/metadata_agent.ini -O /etc/neutron/metadata_agent.ini
wget http://172.17.0.1:8000/etc/neutron/plugins/ml2/linuxbridge_agent.ini -O /etc/neutron/plugins/ml2/linuxbridge_agent.ini
wget http://172.17.0.1:8000/etc/neutron/plugins/ml2/ml2_conf.ini -O /etc/neutron/plugins/ml2/ml2_conf.ini
echo "CREATE DATABASE neutron" | mysql
echo "GRANT ALL PRIVILEGES ON neutron.* TO 'neutron'@'localhost' IDENTIFIED BY '$NEUTRON_DBPASS'" | mysql
echo "GRANT ALL PRIVILEGES ON neutron.* TO 'neutron'@'%' IDENTIFIED BY '$NEUTRON_DBPASS'" | mysql
neutron-db-manage --config-file /etc/neutron/neutron.conf --config-file /etc/neutron/plugins/ml2/ml2_conf.ini upgrade head

openstack user create --domain default --password $NEUTRON_PASS neutron
openstack role add --project service --user neutron admin
openstack service create --name neutron --description "OpenStack Networking" network
openstack endpoint create --region RegionOne network public http://controller:9696
openstack endpoint create --region RegionOne network internal http://controller:9696
openstack endpoint create --region RegionOne network admin http://controller:9696

service nova-api restart
service nova-compute stop
service nova-compute start

service neutron-server start
service neutron-linuxbridge-agent start
service neutron-dhcp-agent start
service neutron-metadata-agent start

neutron ext-list
